const mongoose = require("mongoose");

const docsSchema = mongoose.Schema({
  docsPath: { type: String, required: true },
  creator: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  docType: { type: String, enum:['isr','lmp','pocmr'], required: true }
});

module.exports = mongoose.model("Docs", docsSchema);
