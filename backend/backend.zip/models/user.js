const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const userSchema = mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  isEmailVerified: { type: Boolean },
  registrationStep: { type: Number, enum: [0,1,2,3]},
  regDate: { type: Date },
  companyName: { type: String },
  oib: { type: String },
  telephone: { type: String },
  address: { type: String },
  city: { type: String },
  countryCode: { type: String },
  postalCode: { type: String },
  userType: { type: String, enum:['firms','drivers','both']},
  approved: { type: Boolean }
});

userSchema.plugin(uniqueValidator);

module.exports = mongoose.model("User", userSchema);
