const mongoose = require("mongoose");

const truckSchema = mongoose.Schema({
  truckModel: { type: String, required: true },
  truckType: { type: String, required: true },
  year: { type: String, required: true },
  regNumber: { type: String, required: true },
  regDate: { type: String, required: true },
  maxWeight: { type: String, required: true },
  cargoType: { type: String, required: true },
  chassis: { type: String, required: true },
  height: { type: String, required: true },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
});

module.exports = mongoose.model("Truck", truckSchema);
