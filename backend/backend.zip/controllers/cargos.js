const Cargo = require("../models/cargo");

exports.createCargo = (req, res, next) => {
  const url = req.protocol + "://" + req.get("host");
  const cargo = new Cargo({
    title: req.body.title,
    content: req.body.content,
    imagePath: url + "/images/" + req.file.filename,
    creator: req.userData.userId
  });
  cargo
    .save()
    .then(createdCargo => {
      res.status(201).json({
        message: "Cargo added successfully",
        post: {
          ...createdCargo,
          id: createdCargo._id
        }
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Creating a post failed!"
      });
    });
};

exports.updateCargo = (req, res, next) => {
  let imagePath = req.body.imagePath;
  if (req.file) {
    const url = req.protocol + "://" + req.get("host");
    imagePath = url + "/images/" + req.file.filename;
  }
  const cargo = new Cargo({
    _id: req.body.id,
    title: req.body.title,
    content: req.body.content,
    imagePath: imagePath,
    creator: req.userData.userId
  });
  Cargo.updateOne({ _id: req.params.id, creator: req.userData.userId }, cargo)
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "Update successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't udpate post!"
      });
    });
};

exports.getCargos = (req, res, next) => {
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  const cargoQuery = Cargo.find();
  let fetchedCargos;
  if (pageSize && currentPage) {
    cargoQuery.skip(pageSize * (currentPage - 1)).limit(pageSize);
  }
  cargoQuery
    .then(documents => {
      fetchedCargos = documents;
      return Cargo.count();
    })
    .then(count => {
      res.status(200).json({
        message: "Posts fetched successfully!",
        cargos: fetchedCargos,
        maxCargos: count
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching posts failed!"
      });
    });
};

exports.getCargo = (req, res, next) => {
  Cargo.findById(req.params.id)
    .then(cargo => {
      if (cargo) {
        res.status(200).json(cargo);
      } else {
        res.status(404).json({ message: "Post not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching post failed!"
      });
    });
};

exports.deleteCargo = (req, res, next) => {
  Cargo.deleteOne({ _id: req.params.id, creator: req.userData.userId })
    .then(result => {
      console.log(result);
      if (result.n > 0) {
        res.status(200).json({ message: "Deletion successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Deleting posts failed!"
      });
    });
};
