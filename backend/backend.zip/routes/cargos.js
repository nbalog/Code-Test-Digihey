const express = require("express");

const CargoController = require("../controllers/cargos");

const checkAuth = require("../middleware/check-auth");
const extractFile = require("../middleware/file");

const router = express.Router();

router.post("", checkAuth, extractFile, CargoController.createCargo);

router.put("/:id", checkAuth, extractFile, CargoController.updateCargo);

router.get("", CargoController.getCargos);

router.get("/:id", CargoController.getCargo);

router.delete("/:id", checkAuth, CargoController.deleteCargo);

module.exports = router;
