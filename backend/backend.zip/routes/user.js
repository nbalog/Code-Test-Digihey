const express = require("express");

const UserController = require("../controllers/user");
const extractDocsFile = require("../middleware/docsfile");
const checkAuth = require("../middleware/check-auth");

const router = express.Router();

/*Public*/
router.post("/signup", UserController.createUser);
router.put("/signupStep1/:id", checkAuth, UserController.createUserStep1);
router.put("/signupStep2/:id", checkAuth, UserController.createUserStep2);
router.post("/login", UserController.userLogin);
router.get("/confirmation", UserController.confirmationPost);
router.get("/getUserData/:id", UserController.getUserData);
router.post("/docs", checkAuth, extractDocsFile, UserController.createDocs);

/*Admin*/
router.get("/getUsers", UserController.getUsers);
router.get("/getDocs/:id", UserController.getDocs);
module.exports = router;
